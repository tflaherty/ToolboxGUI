console.log('This would be the main JS file.');
